package com.springboot2.learnspringboot2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnSpringboot2Application {

	public static void main(String[] args) {
		SpringApplication.run(LearnSpringboot2Application.class, args);
	}

}
